﻿  <link type="text/css" rel="stylesheet" href="/help/css/page_3.css" />
			
	<div class="wrap-bg">
		<div class="wrapper">
			<div class="activities">
		        <div class="select clearfix">
			        <ul class="top_tab">
			            <li id="tab_1" class="on"><a onclick="setTab(1)">全部活动</a></li>
			        </ul>
		    	</div>
		        <div class="ac_list">
		            <div id="act_1" style="display: block;">
		            	
		                <table cellpadding="0" cellspacing="0" border="0" class="ac_list_table">
		                <tbody>
		                <tr>
		                    <td class="ac_img">
		                        <a href="javascript:;"><img src="/help/picture/member_1.png"/></a>
		                    </td>
		                    <td>
		                        <div class="td_wrapper">
		                            <h2><a>新会员注册下载APP送18元</a></h2>
		                            <ul class="info">
		                                <li class="rules"><a></a></li>
		                                <li class="applicable"><em></em>活动对象：<span class="grey">所有新注册会员</span></li>
		                                <li class="date"><em></em>活动内容：<span class="grey">下载APP</span></li>
		                            </ul>
		                            <a class="join">查看详情</a>
		                        </div>
		                    </td>
		                </tr>
		                </tbody>
		                </table>
		                <!-- 下拉详情 -->
		                <div id="activity_3" class="xialawz" style="display: none;">
		                    <p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-family: &#39;Microsoft Yahei&#39; font-size: 12px; white-space: normal;"><span style="color: rgb(12, 21, 38); line-height: 24px; font-family: 微软雅黑; background-color: rgb(255, 0, 0);">●</span><span style="line-height: 24px; font-family: 微软雅黑; background-color: rgb(255, 0, 0);"><span style="color: rgb(141, 139, 129); font-weight: 700;"><strong><span style="color: rgb(255, 255, 0);">彩票89</span></strong></span><span style="color: rgb(12, 21, 38);">●&nbsp;</span><span style="color:#ffffff"><strong>易记</strong><strong>网址：cp89.com&nbsp;</strong></span><span style="color: rgb(12, 21, 38);">●<strong>大品牌</strong></span></span><strong style="color: rgb(103, 103, 103);"><span style="color: rgb(255, 255, 0); line-height: 24px; font-family: 微软雅黑; font-weight: normal; background-color: rgb(255, 0, 0);">&nbsp;值得信赖</span></strong><span style="color: rgb(255, 255, 0); line-height: 24px; font-family: 微软雅黑; background-color: rgb(255, 0, 0);">！</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;">彩票89官方网址：www.cp89.com<br/>彩票89是世界彩界著名线上数字娱乐平台之一,专注于彩票事业。&nbsp;<br/>彩票89获得GEOTRUST国际认证,实力彩票娱乐平台，&nbsp;<span style="background-color: rgb(255, 153, 0);">彩种丰富玩法多样</span>（如：时时彩,香港彩,北京PK10,快乐十分,快三,五分彩等）。<br/></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-family: 微软雅黑; line-height: 1.5;"><br/><span style="color: rgb(229, 51, 51); font-family: 微软雅黑; font-size: 12px; line-height: 18px; white-space: normal;">下载手机APP 注册自动送18元幸运彩金：&nbsp;</span></span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-family: 微软雅黑; line-height: 1.5;"><br/>尊敬的会员您好 为方便大家下注并能第一时间进入彩票89平台，现已推出手机APP（苹果IOS和安卓系统），请大家及时下载。推广活动中完善资料并充值100元以上，系统将自动赠送18元哦 （如没收到请退出然后重新登入）</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-family: &#39;Microsoft Yahei&#39;; white-space: normal;"><span style="font-family: SimSun; line-height: 24px;"><span style="color: rgb(0, 0, 0);"><br/><strong><span style="font-size:16px">苹果IOS下载地址：</span></strong></span><a href="https://itunes.apple.com/cn/app/id1236682873?mt=8" target="_blank"><span style="color:#0070c0"><strong><span style="font-size:16px">请点击此处进入下载</span></strong></span></a></span><span style="color: rgb(0, 0, 0);"><strong><span style="font-size:16px"><span style="color: rgb(229, 51, 51);"></span></span></strong></span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-family: &#39;Microsoft Yahei&#39;; white-space: normal;"><span style="font-family: SimSun; line-height: 24px;"><strong><span style="font-size:16px"><span style="color:#000000">安卓Android下载地址：</span><span style="font-family: SimSun; line-height: 24px; white-space: normal;"><a href="https://www.cp89002.bet/uploadimg/cp89_1.0.apk" target="_blank"><span style="color: rgb(0, 112, 192);">请点击此处进入下载</span></a></span></span></strong></span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-family: 微软雅黑;"><br/>活动细则：</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-family: 微软雅黑;">1、赢到<span style="color: rgb(229, 51, 51);"><strong>100</strong></span>元即可出款。<br/></span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-family: 微软雅黑;">2、完善个人信息，绑定您要提现的银行卡, 派送18元彩金的用户出款不能更换银行信息。</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;">3、参与本活动需要遵守彩票89公司相关规则,如发现任何利用活动或技术漏洞对冲等恶意套利行为，彩票89公司将扣除所有违规所得,并且有权冻结其账号。</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;">4、本活动最终解释权和裁决权归彩票89公司所有，彩票89公司保留修改暂停终止该优惠活动等所有权利。</p>
		                </div>
		           		
		                <table cellpadding="0" cellspacing="0" border="0" class="ac_list_table">
		                <tbody>
		                <tr>
		                    <td class="ac_img">
		                        <a href="javascript:;"><img src="/help/picture/14958721031600.jpg"/></a>
		                    </td>
		                    <td>
		                        <div class="td_wrapper">
		                            <h2><a>推荐好友获取收益</a></h2>
		                            <ul class="info">
		                                <li class="rules"><a></a></li>
		                                <li class="applicable"><em></em>活动对象：<span class="grey">所有会员</span></li>
		                                <li class="date"><em></em>活动内容：<span class="grey">推荐好友获取收益</span></li>
		                            </ul>
		                            <a class="join">查看详情</a>
		                        </div>
		                    </td>
		                </tr>
		                </tbody>
		                </table>
		                <!-- 下拉详情 -->
		                <div id="activity_8" class="xialawz" style="display: none;">
		                    <p><span style="white-space: nowrap;font-size:16px">推荐好友获取收益: 请复制完整地址给您的好友或者让您的好友在注册时填写您的推荐ID</span></p><p><span style="white-space: nowrap;font-size:16px"><br/></span></p><p><span style="white-space: nowrap;font-size:16px">您推荐会员的有效投注额度总和（不管输赢都计算） 您将从中获取收益</span></p><p><span style="white-space: nowrap;font-size:16px"><br/></span></p><p><span style="white-space: nowrap;font-size:16px">详细请进入 我的个人中心 -&gt; 我的推荐 进行查看。</span></p><p><span style="white-space: nowrap;"><br/></span></p>
		                </div>
		           		
		                <table cellpadding="0" cellspacing="0" border="0" class="ac_list_table">
		                <tbody>
		                <tr>
		                    <td class="ac_img">
		                        <a href="javascript:;"><img src="/help/picture/14958720583470.jpg"/></a>
		                    </td>
		                    <td>
		                        <div class="td_wrapper">
		                            <h2><a>天天签到红包</a></h2>
		                            <ul class="info">
		                                <li class="rules"><a></a></li>
		                                <li class="applicable"><em></em>活动对象：<span class="grey">所有会员</span></li>
		                                <li class="date"><em></em>活动内容：<span class="grey">天天签到红包</span></li>
		                            </ul>
		                            <a class="join">查看详情</a>
		                        </div>
		                    </td>
		                </tr>
		                </tbody>
		                </table>
		                <!-- 下拉详情 -->
		                <div id="activity_7" class="xialawz" style="display: none;">
		                    <p><span style="white-space: nowrap;font-size:16px">天天签到 天天有红包 不止一天哦</span></p><p><span style="white-space: nowrap;font-size:16px"><br/></span></p><p><span style="white-space: nowrap;font-size:16px">领取说明</span></p><p><span style="white-space: nowrap;font-size:16px">&nbsp; &nbsp; 1) 计算公式：红包金额=充值总额(最近三天)*赠送百分比</span></p><p><span style="white-space: nowrap;font-size:16px">&nbsp; &nbsp; 2) 假设今天是4/8，充值总额=(4/7充值)+(4/6充值)+(4/5充值)</span></p><p><span style="white-space: nowrap;font-size:16px">&nbsp; &nbsp; 3) 每个会员每天只能签到一次</span></p><p><span style="white-space: nowrap;font-size:16px"><br/></span></p><p><span style="white-space: nowrap;font-size:16px"><br/></span></p><p><span style="white-space: nowrap;font-size:16px">详细请进入 我的个人中心 -&gt; 签到红包 进行查看。</span></p><p><br/></p>
		                </div>
		           		
		                <table cellpadding="0" cellspacing="0" border="0" class="ac_list_table">
		                <tbody>
		                <tr>
		                    <td class="ac_img">
		                        <a href="javascript:;"><img src="/help/picture/new.png"/></a>
		                    </td>
		                    <td>
		                        <div class="td_wrapper">
		                            <h2><a>彩票89最新热点</a></h2>
		                            <ul class="info">
		                                <li class="rules"><a></a></li>
		                                <li class="applicable"><em></em>活动对象：<span class="grey">所有会员</span></li>
		                                <li class="date"><em></em>活动内容：<span class="grey">2000免费试玩 不能提款</span></li>
		                            </ul>
		                            <a class="join">查看详情</a>
		                        </div>
		                    </td>
		                </tr>
		                </tbody>
		                </table>
		                <!-- 下拉详情 -->
		                <div id="activity_5" class="xialawz" style="display: none;">
		                    <p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-family: 微软雅黑; line-height: 24px; color: rgb(12, 21, 38); background-color: rgb(255, 0, 0);">●</span><span style="font-family: 微软雅黑; line-height: 24px; color: rgb(141, 139, 129); background-color: rgb(255, 0, 0);"><span style="font-weight: 700;"><strong><span style="color: rgb(255, 255, 0);">彩票89</span></strong></span><span style="color: rgb(12, 21, 38);">●</span><strong><span style="color: rgb(0, 255, 0);">易记</span></strong><span style="color: rgb(0, 255, 0);"><strong>网址：cp89.com</strong></span><span style="color: rgb(255, 255, 255);"><strong>&nbsp;</strong></span><span style="color: rgb(12, 21, 38);">●<strong>大品牌，</strong></span></span><strong><span style="color: rgb(255, 255, 0); line-height: 24px; font-weight: normal; background-color: rgb(255, 0, 0);">&nbsp;值得信赖</span></strong><span style="font-family: 微软雅黑; line-height: 24px; color: rgb(255, 255, 0); background-color: rgb(255, 0, 0);">！</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="color: rgb(103, 103, 103); font-size: 16px;">1：点击右上角&nbsp;</span><span style="font-size: 16px;color:#e36c09"><a href="http://common/register?type=2" target="_self">免费试玩</a></span><span style="color: rgb(103, 103, 103); font-size: 16px;"><a href="http://common/register?type=2" target="_self">&nbsp;</a>马上就可获得一个试玩账号&nbsp;</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-size: 16px;">2：设置密码就可以马上登入。</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-size: 16px;">3：免费试玩账号不可以申请出款。</span></p><p><br/></p>
		                </div>
		           		
		                <table cellpadding="0" cellspacing="0" border="0" class="ac_list_table">
		                <tbody>
		                <tr>
		                    <td class="ac_img">
		                        <a href="javascript:;"><img src="/help/picture/14980994724290_1.png"/></a>
		                    </td>
		                    <td>
		                        <div class="td_wrapper">
		                            <h2><a>支付方式</a></h2>
		                            <ul class="info">
		                                <li class="rules"><a></a></li>
		                                <li class="applicable"><em></em>活动对象：<span class="grey">所有会员</span></li>
		                                <li class="date"><em></em>活动内容：<span class="grey">支持支付宝，微信，银行转账，在线支付</span></li>
		                            </ul>
		                            <a class="join">查看详情</a>
		                        </div>
		                    </td>
		                </tr>
		                </tbody>
		                </table>
		                <!-- 下拉详情 -->
		                <div id="activity_4" class="xialawz" style="display: none;">
		                    <table border="1" cellspacing="0" cellpadding="0" style="font-size: 12px;white-space: normal;width: 799px;text-align: center;color: rgb(141, 139, 129);font-family: 微软雅黑"><tbody><tr><td style=";padding: 0px;background-color: rgb(172, 26, 198)"><span style="color: rgb(12, 21, 38)">●cp89</span><span style="font-weight: 700"><strong><span style="color: rgb(255, 255, 0)">彩票</span></strong></span><span style="color: rgb(12, 21, 38)">●</span><strong><span style="color: rgb(0, 255, 0)">易记</span></strong><span style="color: rgb(0, 255, 0)"><strong>网址：cp89.com</strong></span><span style="color: rgb(255, 255, 255)"><strong>&nbsp;</strong></span><span style="color: rgb(12, 21, 38)">●</span><strong>大品牌， 值得信赖</strong>！</td></tr></tbody></table><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;color: rgb(103, 103, 103);font-size: 12px;white-space: normal;font-family: 微软雅黑"><strong><span style="color: rgb(255, 229, 0)">支持支付宝</span></strong><span style="font-family: &#39;sans serif&#39;, tahoma, verdana, helvetica;color: rgb(255, 229, 0)"><strong>，微信，银行转账，在线支付</strong></span><strong>，入款最低</strong><span style="font-family: &#39;sans serif&#39;, tahoma, verdana, helvetica;color: rgb(229, 51, 51)"><strong>10</strong></span><strong>元起，出款最低</strong><span style="font-family: &#39;sans serif&#39;, tahoma, verdana, helvetica;color: rgb(229, 51, 51)"><strong>100</strong></span><strong>元起。</strong></p><h4 style=";padding: 0px;font-size: 12px;color: rgb(103, 103, 103);white-space: normal;font-family: 微软雅黑">彩票89提供更全面的支付方式，支付宝、微信支付、银行转账、在线快速支付等渠道多管齐下<span style="color: rgb(153, 187, 0)">，360度无死角</span><span style="font-size: 16px"><span style="font-size: 12px">满足彩民入款需求的同时，要求出款系统3—10分钟的急速出款到客户账上。</span><br/></span><span style="font-size: 16px"><span style="font-size: 12px">入款方式：</span><br/></span><span style="font-size: 16px"><span style="font-size: 12px">微信支付：</span><br/></span><span style="color: rgb(229, 51, 51)">手机APP和WAP支付方式</span><span style="font-size: 16px;color: rgb(229, 51, 51)"><span style="font-size: 12px">：点击存款与提款→充值→选择微信→下一步→立即充值→将为您截屏二维码确认→打开微信→打开扫一扫→相册选择二维码→1.扫一扫支付 2.添加好友进行支付→支付成功后点击我已支付→等待客服审核→完成支付。</span><br/></span><span style="color: rgb(229, 102, 0)">电脑网页支付方式：</span><span style="font-size: 16px;color: rgb(229, 102, 0)"><span style="font-size: 12px">用户中心→在线存款→微信支付→输入存款姓名和金额→打开微信扫一扫二维码进行支付→支付成功后→点击我已支付→等待客服审核→完成支付。</span><br/></span><span style="color: rgb(0, 102, 0);font-size: 16px"><span style="font-size: 12px">支付宝支付：</span><br/></span><span style="font-size: 16px;color: rgb(255, 153, 0)"><span style="font-size: 12px">手机APP和WAP支付方式：点击存款与提款→充值→选择支付宝→下一步→立即充值→将为您截屏二维码确认→打开支付宝→打开扫一扫→相册选择二维码→扫一扫支付→支付成功后点击我已支付→等待客服审核→完成支付。</span><br/></span><span style="font-size: 16px;color: rgb(255, 229, 0)"><span style="font-size: 12px">电脑网页支付方式：用户中心→在线存款→支付宝支付→输入存款姓名和金额→打开支付宝扫一扫二维码进行支付→支付成功后→点击我已支付→等待客服审核→完成支付。</span><br/></span><span style="color: rgb(0, 153, 0);font-size: 16px"><span style="font-size: 12px">在线支付：</span><br/></span><span style="font-size: 16px;color: rgb(0, 153, 0)"><span style="font-size: 12px">手机APP和WAP支付方式：点击存款与提款→充值→选择在线支付→选择入款银行→下一步→立即充值→将进入第三方支付操作平台→按步操作→支付成功后→秒到账无需审核。</span><br/></span><span style="font-size: 16px;color: rgb(0, 102, 0)"><span style="font-size: 12px">电脑网页支付方式：用户中心→在线存款→在线支付→输入存款姓名和金额→进入第三方支付平台进行支付→支付成功后→秒到账无需审核。</span><br/></span><span style="font-size: 16px"><span style="font-size: 12px">银行转账：</span><br/></span><span style="font-size: 16px;color: rgb(96, 217, 120)"><span style="font-size: 12px">手机APP和WAP支付方式：点击存款与提款→充值→选择银行转账→下一步→选择收款银行→下一步→打开您使用的支付银行方式（手机网银转账、ATM转账、柜台汇款）→复制收款银行相关信息→进行支付→支付成功→输入存款姓名→点击我已支付→等待客服审核→完成支付。</span><br/></span><span style="font-size: 16px;color: rgb(0, 213, 255)"><span style="font-size: 12px">电脑网页支付方式：用户中心→在线存款→银行转账→选择银行转账→下一步→选择收款银行→下一步→打开您使用的支付银行方式（手机网银转账、ATM转账、柜台汇款）→复制收款银行相关信息→进行支付→支付成功→输入存款姓名→点击我已支付→等待客服审核→完成支付。</span><br/></span></h4><h2 style=";padding: 0px;font-size: 12px;color: rgb(103, 103, 103);font-family: &#39;Microsoft Yahei&#39;"><span style="font-size: 18px"><strong></strong></span><span style="font-size: 18px;line-height: 1.5"><strong>出入款标准</strong></span><span style="font-size: 18px;line-height: 1.5"><strong></strong></span></h2><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;color: rgb(103, 103, 103);font-family: &#39;Microsoft Yahei&#39;;font-size: 12px;white-space: normal"></p><table border="1" cellspacing="0" cellpadding="0" width="484" style="font-size: 14px;color: rgb(103, 103, 103);font-family: &#39;Microsoft Yahei&#39;;white-space: normal;width: 484px;border: none"><tbody><tr><td width="59" rowspan="2" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><strong><span style="font-size: 13px;font-family: 宋体">方支付式</span></strong></p></td><td colspan="3" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><strong><span style="font-size: 12px;font-family: 宋体">入款标准</span></strong></p></td><td width="219" colspan="3" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><strong><span style="font-size: 12px;font-family: 宋体">出款标准</span></strong></p></td></tr><tr><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">最低入款</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">单笔最高入款</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">单日最高入款</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">最低出款</span></p></td><td width="84" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">单笔最高出款</span></p></td><td width="83" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">单日最高出款</span></p></td></tr><tr><td width="59" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">支付宝</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">10</span><span style="font-size: 12px;font-family: 宋体">元</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">5</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td><td rowspan="4" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">无限制</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">100</span><span style="font-size: 12px;font-family: 宋体">元</span></p></td><td width="84" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">200</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td><td width="83" rowspan="4" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">2000</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td></tr><tr><td width="59" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">微信</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">10</span><span style="font-size: 12px;font-family: 宋体">元</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">5</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">100</span><span style="font-size: 12px;font-family: 宋体">元</span></p></td><td width="84" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">200</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td></tr><tr><td width="59" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">公司入款</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">100</span><span style="font-size: 12px;font-family: 宋体">元</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">200</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">100</span><span style="font-size: 12px;font-family: 宋体">元</span></p></td><td width="84" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">500</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td></tr><tr><td width="59" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px;font-family: 宋体">在线支付</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">100</span><span style="font-size: 12px;font-family: 宋体">元</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">20</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td><td style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">100</span><span style="font-size: 12px;font-family: 宋体">元</span></p></td><td width="84" style=";padding: 0px;border-width: 1px;border-style: inset;border-color: black"><p style="margin-top: 0px;margin-bottom: 0px;padding: 0px;text-align: center"><span style="font-size: 12px">500</span><span style="font-size: 12px;font-family: 宋体">万</span></p></td></tr></tbody></table>
		                </div>
		           		
		                <table cellpadding="0" cellspacing="0" border="0" class="ac_list_table">
		                <tbody>
		                <tr>
		                    <td class="ac_img">
		                        <a href="javascript:;"><img src="/help/picture/welcome.png"/></a>
		                    </td>
		                    <td>
		                        <div class="td_wrapper">
		                            <h2><a>彩票89欢迎您</a></h2>
		                            <ul class="info">
		                                <li class="rules"><a></a></li>
		                                <li class="applicable"><em></em>活动对象：<span class="grey">所有会员</span></li>
		                                <li class="date"><em></em>活动内容：<span class="grey">彩票89欢迎您</span></li>
		                            </ul>
		                            <a class="join">查看详情</a>
		                        </div>
		                    </td>
		                </tr>
		                </tbody>
		                </table>
		                <!-- 下拉详情 -->
		                <div id="activity_1" class="xialawz" style="display: none;">
		                    <p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-family: 微软雅黑; line-height: 24px; color: rgb(12, 21, 38); background-color: rgb(255, 0, 0);"><span style="line-height: 24px;">●cp89</span><span style="line-height: 24px; color: rgb(141, 139, 129);"><span style="font-weight: 700;"><strong><span style="color: rgb(255, 255, 0);">彩票</span></strong></span><span style="color: rgb(12, 21, 38);">●</span><strong><span style="color: rgb(0, 255, 0);">易记</span></strong><span style="color: rgb(0, 255, 0);"><strong>网址：cp89.com</strong></span><span style="color: rgb(12, 21, 38);">●</span><span style="color: rgb(12, 21, 38);"><strong>大品牌，</strong></span></span><strong><span style="color: rgb(255, 255, 0); line-height: 24px; font-weight: normal;">&nbsp;值得信赖</span></strong><span style="line-height: 24px; color: rgb(255, 255, 0);">！</span></span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(103, 103, 103); font-family: &quot;Microsoft Yahei&quot;; font-size: 12px; white-space: normal;"><span style="font-size: 16px;">彩票89官方网址：www.cp89.com</span><br/><span style="font-size: 16px;">彩票89是世界彩界著名线上数字娱乐平台之一，由彩票专家研发高端程序,专注于彩票事业。</span><br/><span style="font-size: 16px;">彩票89获得GEOTRUST国际认证,实力彩票娱乐平台，彩种丰富玩法多样（如：时时彩,香港彩,北京PK10,快乐十分,快三,五分彩等）。</span></p><p><br/></p>
		                </div>
		           		
		           	</div>
		        </div>
		    </div>
    	</div>
	</div>
	<script src="js/require_3.js"></script>
    <script src="js/require.config_3.js"></script>
    <script type="text/javascript">
       $(function(){
            $(".ac_list_table").on("click",function(){
            	var display = $(this).next(".xialawz").css("display");
                $(".ac_list_table").next(".xialawz").hide();
                
                if(display == 'none') {
                	$(this).next(".xialawz").show();
                } else {
                	$(this).next(".xialawz").hide();
                }
            });
        });
    </script>

	