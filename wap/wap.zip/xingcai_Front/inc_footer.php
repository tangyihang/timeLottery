<div class="m_footer_annotation" style="padding-bottom: 30px;">
                        未满18周岁禁止购买<br>
                Copyright © SinCai  彩38 版权所有
                <!-- <a href="#" class="m_f_top"></a> -->
</div>
<div class="padding_fot_b20 "></div>
<!--<div class="m_fx_footer">
    <div class="v-moeny">
            <div class="you-money">
                <span class="t_money rounded" title="0.0000">
                    <div class="show-money" style="display: block;"><i>余额</i> <span id="refff" title="0.0000"><b>￥0.0000</b></span>
                    <a href="javascript:;" title="隐藏余额">
                     <i class="ic-unlook" title="隐藏余额"></i>
                </a></div>
                    <div class="hide-money" style="display: none;"><i>余额</i> <span><b>￥ ************</b></span> 
                        <a href="javascript:;" title="隐藏余额">
                            <i class="ic-unlook" title="隐藏余额"></i>
                        </a>
                    </div>
                </span> 
                
            </div>
            <div class="chongzhi">
                余额不足?<a class="rech" href="/index.php/cash/recharge">充值</a>
            </div>
        </div>
</div>-->

			