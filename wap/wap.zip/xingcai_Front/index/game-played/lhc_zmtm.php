<input type="hidden" name="playedGroup" value="<?=$this->groupId?>" />
<input type="hidden" name="playedId" value="<?=$this->played?>" />
<input type="hidden" name="type" value="<?=$this->type?>" />
<div class="dGameStatus hklhc lotteryView_lhc" action="tzlhcSelect" length="1">
                <div class="Contentbox" id="Contentbox_0">
        <div class="lhcBox" >
		<dl>
			<dt>
		<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="red">01</span><span class="num" data-id="RteLO01"><?=$this->getLHCRte('RteLO01',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO01" name="LOTTO" acno="01" type="text"></span>
		</dd>
		<dd>
		<span class="red">02</span><span class="num" data-id="RteLO02"><?=$this->getLHCRte('RteLO02',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO02" name="LOTTO" acno="02" type="text"></span>
		</dd><dd>
		<span class="blue">03</span><span class="num" data-id="RteLO03"><?=$this->getLHCRte('RteLO03',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO03" name="LOTTO" acno="03" type="text"></span>
		</dd><dd>
		<span class="blue">04</span><span class="num" data-id="RteLO04"><?=$this->getLHCRte('RteLO04',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO04" name="LOTTO" acno="04" type="text"></span>
		</dd><dd>
		<span class="green">05</span><span class="num" data-id="RteLO05"><?=$this->getLHCRte('RteLO05',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO05" name="LOTTO" acno="05" type="text"></span>
		</dd><dd>
		<span class="green">06</span><span class="num" data-id="RteLO06"><?=$this->getLHCRte('RteLO06',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO06" name="LOTTO" acno="06" type="text"></span>
		</dd><dd>
		<span class="red">07</span><span class="num" data-id="RteLO07"><?=$this->getLHCRte('RteLO07',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO07" name="LOTTO" acno="07" type="text"></span>
		</dd><dd>
		<span class="red">08</span><span class="num" data-id="RteLO08"><?=$this->getLHCRte('RteLO08',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO08" name="LOTTO" acno="08" type="text"></span>
		</dd><dd>
		<span class="blue">09</span><span class="num" data-id="RteLO09"><?=$this->getLHCRte('RteLO09',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO09" name="LOTTO" acno="09" type="text"></span>
		</dd><dd>
		<span class="blue">10</span><span class="num" data-id="RteLO10"><?=$this->getLHCRte('RteLO10',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO10" name="LOTTO" acno="10" type="text"></span>
		</dd></dl>
		<dl>
			<dt>
		<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="green">11</span><span class="num" data-id="RteLO11"><?=$this->getLHCRte('RteLO11',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO11" name="LOTTO"  acno="11" type="text"></span>
		</dd><dd>
		<span class="red">12</span><span class="num" data-id="RteLO12"><?=$this->getLHCRte('RteLO12',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO12" name="LOTTO" acno="12" type="text"></span>
		</dd><dd>
		<span class="red">13</span><span class="num" data-id="RteLO13"><?=$this->getLHCRte('RteLO13',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO13" name="LOTTO" acno="13" type="text"></span>
		</dd><dd>
		<span class="blue">14</span><span class="num" data-id="RteLO14"><?=$this->getLHCRte('RteLO14',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO14" name="LOTTO" acno="14" type="text"></span>
		</dd><dd>
		<span class="blue">15</span><span class="num" data-id="RteLO15"><?=$this->getLHCRte('RteLO15',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO15" name="LOTTO" acno="14" type="text"></span>
		</dd><dd>
		<span class="green">16</span><span class="num" data-id="RteLO16"><?=$this->getLHCRte('RteLO16',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO16" name="LOTTO" acno="16" type="text"></span>
		</dd><dd>
		<span class="green">17</span><span class="num" data-id="RteLO17"><?=$this->getLHCRte('RteLO17',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO17" name="LOTTO" acno="17" type="text"></span>
		</dd><dd>
		<span class="red">18</span><span class="num" data-id="RteLO18"><?=$this->getLHCRte('RteLO18',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO18" name="LOTTO" acno="18" type="text"></span>
		</dd><dd>
		<span class="red">19</span><span class="num" data-id="RteLO19"><?=$this->getLHCRte('RteLO19',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO19" name="LOTTO" acno="19" type="text"></span>
		</dd><dd>
		<span class="blue">20</span><span class="num" data-id="RteLO20"><?=$this->getLHCRte('RteLO20',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLO20" name="LOTTO" acno="20" type="text"></span>
		</dd></dl>
		<dl>
			<dt>
		<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="green">21</span><span class="num" data-id="RteLO21"><?=$this->getLHCRte('RteLO21',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO21" name="LOTTO"  acno="21" type="text"></span>
		</dd><dd>
		<span class="green">22</span><span class="num" data-id="RteLO22"><?=$this->getLHCRte('RteLO22',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO22" name="LOTTO"  acno="22" type="text"></span>
		</dd><dd>
		<span class="red">23</span><span class="num" data-id="RteLO23"><?=$this->getLHCRte('RteLO23',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO23" name="LOTTO"  acno="23" type="text"></span>
		</dd><dd>
		<span class="red">24</span><span class="num" data-id="RteLO24"><?=$this->getLHCRte('RteLO24',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO24" name="LOTTO"  acno="24" type="text"></span>
		</dd><dd>
		<span class="blue">25</span><span class="num" data-id="RteLO25"><?=$this->getLHCRte('RteLO25',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO25" name="LOTTO"  acno="25" type="text"></span>
		</dd><dd>
		<span class="blue">26</span><span class="num" data-id="RteLO26"><?=$this->getLHCRte('RteLO26',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO26" name="LOTTO"  acno="26" type="text"></span>
		</dd><dd>
		<span class="green">27</span><span class="num" data-id="RteLO27"><?=$this->getLHCRte('RteLO27',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO27" name="LOTTO"  acno="27" type="text"></span>
		</dd><dd>
		<span class="green">28</span><span class="num" data-id="RteLO28"><?=$this->getLHCRte('RteLO28',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO28" name="LOTTO"  acno="28" type="text"></span>
		</dd><dd>
		<span class="red">29</span><span class="num" data-id="RteLO29"><?=$this->getLHCRte('RteLO29',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO29" name="LOTTO"  acno="29" type="text"></span>
		</dd><dd>
		<span class="red">30</span><span class="num" data-id="RteLO30"><?=$this->getLHCRte('RteLO30',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO30" name="LOTTO"  acno="30" type="text"></span>
		</dd></dl>
		<dl>
			<dt>
		<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="blue">31</span><span class="num" data-id="RteLO31"><?=$this->getLHCRte('RteLO31',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO31" name="LOTTO" acno="31" type="text"></span>
		</dd><dd>
		<span class="green">32</span><span class="num" data-id="RteLO32"><?=$this->getLHCRte('RteLO32',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO32" name="LOTTO" acno="32" type="text"></span>
		</dd><dd>
		<span class="green">33</span><span class="num" data-id="RteLO33"><?=$this->getLHCRte('RteLO33',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO33" name="LOTTO" acno="33" type="text"></span>
		</dd><dd>
		<span class="red">34</span><span class="num" data-id="RteLO34"><?=$this->getLHCRte('RteLO34',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO34" name="LOTTO" acno="34" type="text"></span>
		</dd><dd>
		<span class="red">35</span><span class="num" data-id="RteLO35"><?=$this->getLHCRte('RteLO35',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO35" name="LOTTO" acno="35" type="text"></span>
		</dd><dd>
		<span class="blue">36</span><span class="num" data-id="RteLO36"><?=$this->getLHCRte('RteLO36',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO36" name="LOTTO" acno="36" type="text"></span>
		</dd><dd>
		<span class="blue">37</span><span class="num" data-id="RteLO37"><?=$this->getLHCRte('RteLO37',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO37" name="LOTTO" acno="37" type="text"></span>
		</dd><dd>
		<span class="green">38</span><span class="num" data-id="RteLO38"><?=$this->getLHCRte('RteLO38',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO38" name="LOTTO" acno="38" type="text"></span>
		</dd><dd>
		<span class="green">39</span><span class="num" data-id="RteLO39"><?=$this->getLHCRte('RteLO39',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO39" name="LOTTO" acno="39" type="text"></span>
		</dd><dd>
		<span class="red">40</span><span class="num" data-id="RteLO40"><?=$this->getLHCRte('RteLO40',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO40" name="LOTTO" acno="40" type="text"></span>
		</dd></dl>
		<dl>
			<dt>
		<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="blue">41</span><span class="num" data-id="RteLO41"><?=$this->getLHCRte('RteLO41',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO41" name="LOTTO" acno="41" type="text"></span>
		</dd><dd>
		<span class="blue">42</span><span class="num" data-id="RteLO42"><?=$this->getLHCRte('RteLO42',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO42" name="LOTTO" acno="42" type="text"></span>
		</dd><dd>
		<span class="green">43</span><span class="num" data-id="RteLO43"><?=$this->getLHCRte('RteLO43',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO43" name="LOTTO" acno="43" type="text"></span>
		</dd><dd>
		<span class="green">44</span><span class="num" data-id="RteLO44"><?=$this->getLHCRte('RteLO44',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO44" name="LOTTO" acno="44" type="text"></span>
		</dd><dd>
		<span class="red">45</span><span class="num" data-id="RteLO45"><?=$this->getLHCRte('RteLO45',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO45" name="LOTTO" acno="45" type="text"></span>
		</dd><dd>
		<span class="red">46</span><span class="num"><?=$this->getLHCRte('RteLO46',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO46" name="LOTTO" acno="46" type="text"></span>
		</dd><dd>
		<span class="blue">47</span><span class="num" data-id="RteLO47"><?=$this->getLHCRte('RteLO47',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO47" name="LOTTO" acno="47" type="text"></span>
		</dd><dd>
		<span class="blue">48</span><span class="num" data-id="RteLO48"><?=$this->getLHCRte('RteLO48',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO48" name="LOTTO" acno="48" type="text"></span>
		</dd>
		<dd>
		<span class="green">49</span><span class="num" data-id="RteLO49"><?=$this->getLHCRte('RteLO49',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteLOTTO49" name="LOTTO" acno="49" type="text"></span>
		</dd><dd>
		</dd>
		</dl>
		
		
		<div class="dGameStatus hklhc lotteryView_lhc1" action="tzlhcSelect" length="1">
                <div class="Contentbox" id="Contentbox_0">
        <div class="lhcBox1" >
	
			<dl class="zmtC">
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		<dd>
		<span class="sGameStatusItem">正一大</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1d"><?=$this->getLHCRte('RteLOzt1d',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1d" name="LTTBSOE" acno="正一大" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">正一小</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1x"><?=$this->getLHCRte('RteLOzt1x',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1x" name="LTTBSOE" acno="正一小" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">正一单</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1dd"><?=$this->getLHCRte('RteLOzt1dd',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1dd" name="LTTBSOE" acno="正一单" type="text"></span>
		</dd>

			</dl>
			<dl class="zmtC">
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		<dd>
		<span id="" class="sGameStatusItem">正一双</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1s"><?=$this->getLHCRte('RteLOzt1s',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1s" name="LTTBSOE" acno="正一双" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">正一合单</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1hd"><?=$this->getLHCRte('RteLOzt1hd',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1hd" name="LTTBSOE" acno="正一合单" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">正一合双</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1ss"><?=$this->getLHCRte('RteLOzt1ss',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1ss" name="LTTBSOE" acno="正一合双" type="text"></span>
		</dd>
			</dl>
		<dl class="zmtC">
		<dt>
			<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
		</dt>
		<dd>
		<span class="sGameStatusItem">正一红</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1h"><?=$this->getLHCRte('RteLOzt1h',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1h" name="LTTBSOE" acno="正一红" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">正一蓝</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1l"><?=$this->getLHCRte('RteLOzt1l',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1l" name="LTTBSOE" acno="正一蓝" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">正一绿</span><span class="num" style="margin-left:12px;" data-id="RteLOzt1lv"><?=$this->getLHCRte('RteLOzt1lv',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteLOzt1lv" name="LTTBSOE" acno="正一绿" type="text"></span>
		</dd>
		</dl>
		</div>
                 
         </div>
              </div>    </div>    </div>
            </div>
		
				<div class="addOrderBox _lhc" >
                <div class="addOrderLeft addOrderLeft625">
                                   
                   <input type="button" class="addBtn" onclick="bringRte();" value="添加投注">
                    <div class="chooseMsg">
                        <p>总金额共 <span id="sTotalCredit">0</span> 元</p>
                    </div>
                </div>
           
            </div>
            
<script>
		$("dd span").click(function(){
			var that = $(this);
			var parent = that.parent();
			if(!that.is(".input") &&　!that.is(".num")){
				if(that.is(".active")){
					 that.removeClass("active").css("background-color","#fff !important");
					 that.get(0).style.cssText='background-color:#fff !important;color:#ca1a1a !important';
					 parent.find('input[type="text"]').val("");
				}else{
					 that.addClass("active");
					 that.get(0).style.cssText='background-color:#ec2829 !important;color:white !important';
					 parent.find('input[type="text"]').val(1);
				}
			}
			parent.find("input").trigger("change");
		});
		$("dd input[type='text']").click(function(e){
			e.stopPropagation();
		})
		$("dd input[type='text']").blur(function(){
			clearCheck($(this));
		})
		 function clearCheck(that){
    	var val = that.val();
    	var lis = that.parents("dd");
    	 if(isNaN(val) && typeof val != 'number' ){
    	 	 that.val("");
    	 };
    	 if(that.val() <= 0){
    	 		that.val("");
    	 };
    	 if(that.val() == ''){
    	 	lis.find("span").eq(0).removeClass("active");
    	 	lis.find("span").eq(0).get(0).style.cssText='background-color:#fff !important;color:#ca1a1a !important';
    	 }else{
    	 	  if(!lis.find("span").eq(0).is(".active")){
    	 	  	 lis.find("span").eq(0).addClass("active");
    	 	  	 lis.find("span").eq(0).get(0).style.cssText='background-color:#ec2829 !important;color:white !important';
    	 	  }
    	 }
    }
	
</script>