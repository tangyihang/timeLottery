<input type="hidden" name="playedGroup" value="<?= $this->groupId ?>" />
<input type="hidden" name="playedId" value="<?= $this->played ?>" />
<input type="hidden" name="type" value="<?= $this->type ?>" />
<div class="dGameStatus hklhc" action="tzlhcSelect" length="1">
        <span class="sTitle">特别号</span>
        <table>
            <tbody><tr>
    
                        <td class="boldborder">
                            <span title="01" class="hkball sCBHKball_01"></span>
                            <span class="sRte" id="RteSP01" style="color: BLUE;"><?= $this->getLHCRte('RteSP01', $this->played) ?></span>
                            <input type="text" tabindex="1" maxlength="5" id="CdtSP01" name="SP"  acno="01">
                        </td>
    
                        <td class="boldborder">
                            <span title="11" class="hkball sCBHKball_11"></span>
                            <span class="sRte" id="RteSP11" style="color: BLUE;"><?= $this->getLHCRte('RteSP11', $this->played) ?></span>
                            <input type="text" tabindex="11" maxlength="5" id="CdtSP11" name="SP"  acno="11">
                        </td>
    
                        <td class="boldborder">
                            <span title="21" class="hkball sCBHKball_21"></span>
                            <span class="sRte" id="RteSP21" style="color: BLUE;"><?= $this->getLHCRte('RteSP21', $this->played) ?></span>
                            <input type="text" tabindex="21" maxlength="5" id="CdtSP21" name="SP"  acno="21">
                        </td>
    
                        <td class="boldborder">
                            <span title="31" class="hkball sCBHKball_31"></span>
                            <span class="sRte" id="RteSP31" style="color: BLUE;"><?= $this->getLHCRte('RteSP31', $this->played) ?></span>
                            <input type="text" tabindex="31" maxlength="5" id="CdtSP31" name="SP"  acno="31">
                        </td>
    
                        <td class="">
                            <span title="41" class="hkball sCBHKball_41"></span>
                            <span class="sRte" id="RteSP41" style="color: BLUE;"><?= $this->getLHCRte('RteSP41', $this->played) ?></span>
                            <input type="text" tabindex="41" maxlength="5" id="CdtSP41" name="SP"  acno="41">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="02" class="hkball sCBHKball_02"></span>
                            <span class="sRte" id="RteSP02" style="color: BLUE;"><?= $this->getLHCRte('RteSP02', $this->played) ?></span>
                            <input type="text" tabindex="2" maxlength="5" id="CdtSP02" name="SP"  acno="02">
                        </td>
    
                        <td class="boldborder">
                            <span title="12" class="hkball sCBHKball_12"></span>
                            <span class="sRte" id="RteSP12" style="color: BLUE;"><?= $this->getLHCRte('RteSP12', $this->played) ?></span>
                            <input type="text" tabindex="12" maxlength="5" id="CdtSP12" name="SP" acno="12">
                        </td>
    
                        <td class="boldborder">
                            <span title="22" class="hkball sCBHKball_22"></span>
                            <span class="sRte" id="RteSP22" style="color: BLUE;"><?= $this->getLHCRte('RteSP22', $this->played) ?></span>
                            <input type="text" tabindex="22" maxlength="5" id="CdtSP22" name="SP" acno="22">
                        </td>
    
                        <td class="boldborder">
                            <span title="32" class="hkball sCBHKball_32"></span>
                            <span class="sRte" id="RteSP32" style="color: BLUE;"><?= $this->getLHCRte('RteSP32', $this->played) ?></span>
                            <input type="text" tabindex="32" maxlength="5" id="CdtSP32" name="SP" acno="32">
                        </td>
    
                        <td class="">
                            <span title="42" class="hkball sCBHKball_42"></span>
                            <span class="sRte" id="RteSP42" style="color: BLUE;"><?= $this->getLHCRte('RteSP42', $this->played) ?></span>
                            <input type="text" tabindex="42" maxlength="5" id="CdtSP42" name="SP" acno="42">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="03" class="hkball sCBHKball_03"></span>
                            <span class="sRte" id="RteSP03" style="color: BLUE;"><?= $this->getLHCRte('RteSP03', $this->played) ?></span>
                            <input type="text" tabindex="3" maxlength="5" id="CdtSP03" name="SP" acno="03">
                        </td>
    
                        <td class="boldborder">
                            <span title="13" class="hkball sCBHKball_13"></span>
                            <span class="sRte" id="RteSP13" style="color: BLUE;"><?= $this->getLHCRte('RteSP13', $this->played) ?></span>
                            <input type="text" tabindex="13" maxlength="5" id="CdtSP13" name="SP" acno="13">
                        </td>
    
                        <td class="boldborder">
                            <span title="23" class="hkball sCBHKball_23"></span>
                            <span class="sRte" id="RteSP23" style="color: BLUE;"><?= $this->getLHCRte('RteSP23', $this->played) ?></span>
                            <input type="text" tabindex="23" maxlength="5" id="CdtSP23" name="SP" acno="23">
                        </td>
    
                        <td class="boldborder">
                            <span title="33" class="hkball sCBHKball_33"></span>
                            <span class="sRte" id="RteSP33" style="color: BLUE;"><?= $this->getLHCRte('RteSP33', $this->played) ?></span>
                            <input type="text" tabindex="33" maxlength="5" id="CdtSP33" name="SP" acno="33">
                        </td>
    
                        <td class="">
                            <span title="43" class="hkball sCBHKball_43"></span>
                            <span class="sRte" id="RteSP43" style="color: BLUE;"><?= $this->getLHCRte('RteSP43', $this->played) ?></span>
                            <input type="text" tabindex="43" maxlength="5" id="CdtSP43" name="SP" acno="43">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="04" class="hkball sCBHKball_04"></span>
                            <span class="sRte" id="RteSP04" style="color: BLUE;"><?= $this->getLHCRte('RteSP04', $this->played) ?></span>
                            <input type="text" tabindex="4" maxlength="5" id="CdtSP04" name="SP" acno="04">
                        </td>
    
                        <td class="boldborder">
                            <span title="14" class="hkball sCBHKball_14"></span>
                            <span class="sRte" id="RteSP14" style="color: BLUE;"><?= $this->getLHCRte('RteSP14', $this->played) ?></span>
                            <input type="text" tabindex="14" maxlength="5" id="CdtSP14" name="SP" acno="14">
                        </td>
    
                        <td class="boldborder">
                            <span title="24" class="hkball sCBHKball_24"></span>
                            <span class="sRte" id="RteSP24" style="color: BLUE;"><?= $this->getLHCRte('RteSP24', $this->played) ?></span>
                            <input type="text" tabindex="24" maxlength="5" id="CdtSP24" name="SP" acno="24">
                        </td>
    
                        <td class="boldborder">
                            <span title="34" class="hkball sCBHKball_34"></span>
                            <span class="sRte" id="RteSP34" style="color: BLUE;"><?= $this->getLHCRte('RteSP34', $this->played) ?></span>
                            <input type="text" tabindex="34" maxlength="5" id="CdtSP34" name="SP" acno="34">
                        </td>
    
                        <td class="">
                            <span title="44" class="hkball sCBHKball_44"></span>
                            <span class="sRte" id="RteSP44" style="color: BLUE;"><?= $this->getLHCRte('RteSP44', $this->played) ?></span>
                            <input type="text" tabindex="44" maxlength="5" id="CdtSP44" name="SP" acno="44">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="05" class="hkball sCBHKball_05"></span>
                            <span class="sRte" id="RteSP05" style="color: BLUE;"><?= $this->getLHCRte('RteSP05', $this->played) ?></span>
                            <input type="text" tabindex="5" maxlength="5" id="CdtSP05" name="SP" acno="05">
                        </td>
    
                        <td class="boldborder">
                            <span title="15" class="hkball sCBHKball_15"></span>
                            <span class="sRte" id="RteSP15" style="color: BLUE;"><?= $this->getLHCRte('RteSP15', $this->played) ?></span>
                            <input type="text" tabindex="15" maxlength="5" id="CdtSP15" name="SP" acno="15">
                        </td>
    
                        <td class="boldborder">
                            <span title="25" class="hkball sCBHKball_25"></span>
                            <span class="sRte" id="RteSP25" style="color: BLUE;"><?= $this->getLHCRte('RteSP25', $this->played) ?></span>
                            <input type="text" tabindex="25" maxlength="5" id="CdtSP25" name="SP" acno="25">
                        </td>
    
                        <td class="boldborder">
                            <span title="35" class="hkball sCBHKball_35"></span>
                            <span class="sRte" id="RteSP35" style="color: BLUE;"><?= $this->getLHCRte('RteSP35', $this->played) ?></span>
                            <input type="text" tabindex="35" maxlength="5" id="CdtSP35" name="SP" acno="35">
                        </td>
    
                        <td class="">
                            <span title="45" class="hkball sCBHKball_45"></span>
                            <span class="sRte" id="RteSP45" style="color: BLUE;"><?= $this->getLHCRte('RteSP45', $this->played) ?></span>
                            <input type="text" tabindex="45" maxlength="5" id="CdtSP45" name="SP" acno="45">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="06" class="hkball sCBHKball_06"></span>
                            <span class="sRte" id="RteSP06" style="color: BLUE;"><?= $this->getLHCRte('RteSP06', $this->played) ?></span>
                            <input type="text" tabindex="6" maxlength="5" id="CdtSP06" name="SP" acno="06">
                        </td>
    
                        <td class="boldborder">
                            <span title="16" class="hkball sCBHKball_16"></span>
                            <span class="sRte" id="RteSP16" style="color: BLUE;"><?= $this->getLHCRte('RteSP16', $this->played) ?></span>
                            <input type="text" tabindex="16" maxlength="5" id="CdtSP16" name="SP" acno="16">
                        </td>
    
                        <td class="boldborder">
                            <span title="26" class="hkball sCBHKball_26"></span>
                            <span class="sRte" id="RteSP26" style="color: BLUE;"><?= $this->getLHCRte('RteSP26', $this->played) ?></span>
                            <input type="text" tabindex="26" maxlength="5" id="CdtSP26" name="SP" acno="26">
                        </td>
    
                        <td class="boldborder">
                            <span title="36" class="hkball sCBHKball_36"></span>
                            <span class="sRte" id="RteSP36" style="color: BLUE;"><?= $this->getLHCRte('RteSP36', $this->played) ?></span>
                            <input type="text" tabindex="36" maxlength="5" id="CdtSP36" name="SP" acno="36">
                        </td>
    
                        <td class="">
                            <span title="46" class="hkball sCBHKball_46"></span>
                            <span class="sRte" id="RteSP46" style="color: BLUE;"><?= $this->getLHCRte('RteSP46', $this->played) ?></span>
                            <input type="text" tabindex="46" maxlength="5" id="CdtSP46" name="SP"  acno="47">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="07" class="hkball sCBHKball_07"></span>
                            <span class="sRte" id="RteSP07" style="color: BLUE;"><?= $this->getLHCRte('RteSP07', $this->played) ?></span>
                            <input type="text" tabindex="7" maxlength="5" id="CdtSP07" name="SP"  acno="07">
                        </td>
    
                        <td class="boldborder">
                            <span title="17" class="hkball sCBHKball_17"></span>
                            <span class="sRte" id="RteSP17" style="color: BLUE;"><?= $this->getLHCRte('RteSP17', $this->played) ?></span>
                            <input type="text" tabindex="17" maxlength="5" id="CdtSP17" name="SP" acno="17">
                        </td>
    
                        <td class="boldborder">
                            <span title="27" class="hkball sCBHKball_27"></span>
                            <span class="sRte" id="RteSP27" style="color: BLUE;"><?= $this->getLHCRte('RteSP27', $this->played) ?></span>
                            <input type="text" tabindex="27" maxlength="5" id="CdtSP27" name="SP" acno="27">
                        </td>
    
                        <td class="boldborder">
                            <span title="37" class="hkball sCBHKball_37"></span>
                            <span class="sRte" id="RteSP37" style="color: BLUE;"><?= $this->getLHCRte('RteSP37', $this->played) ?></span>
                            <input type="text" tabindex="37" maxlength="5" id="CdtSP37" name="SP" acno="37">
                        </td>
    
                        <td class="">
                            <span title="47" class="hkball sCBHKball_47"></span>
                            <span class="sRte" id="RteSP47" style="color: BLUE;"><?= $this->getLHCRte('RteSP47', $this->played) ?></span>
                            <input type="text" tabindex="47" maxlength="5" id="CdtSP47" name="SP" acno="47">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="08" class="hkball sCBHKball_08"></span>
                            <span class="sRte" id="RteSP08" style="color: BLUE;"><?= $this->getLHCRte('RteSP08', $this->played) ?></span>
                            <input type="text" tabindex="8" maxlength="5" id="CdtSP08" name="SP" acno="08">
                        </td>
    
                        <td class="boldborder">
                            <span title="18" class="hkball sCBHKball_18"></span>
                            <span class="sRte" id="RteSP18" style="color: BLUE;"><?= $this->getLHCRte('RteSP18', $this->played) ?></span>
                            <input type="text" tabindex="18" maxlength="5" id="CdtSP18" name="SP" acno="18">
                        </td>
    
                        <td class="boldborder">
                            <span title="28" class="hkball sCBHKball_28"></span>
                            <span class="sRte" id="RteSP28" style="color: BLUE;"><?= $this->getLHCRte('RteSP28', $this->played) ?></span>
                            <input type="text" tabindex="28" maxlength="5" id="CdtSP28" name="SP" acno="28">
                        </td>
    
                        <td class="boldborder">
                            <span title="38" class="hkball sCBHKball_38"></span>
                            <span class="sRte" id="RteSP38" style="color: BLUE;"><?= $this->getLHCRte('RteSP38', $this->played) ?></span>
                            <input type="text" tabindex="38" maxlength="5" id="CdtSP38" name="SP" acno="38">
                        </td>
    
                        <td class="">
                            <span title="48" class="hkball sCBHKball_48"></span>
                            <span class="sRte" id="RteSP48" style="color: BLUE;"><?= $this->getLHCRte('RteSP48', $this->played) ?></span>
                            <input type="text" tabindex="48" maxlength="5" id="CdtSP48" name="SP" acno="48">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="09" class="hkball sCBHKball_09"></span>
                            <span class="sRte" id="RteSP09" style="color: BLUE;"><?= $this->getLHCRte('RteSP09', $this->played) ?></span>
                            <input type="text" tabindex="9" maxlength="5" id="CdtSP09" name="SP" acno="09">
                        </td>
    
                        <td class="boldborder">
                            <span title="19" class="hkball sCBHKball_19"></span>
                            <span class="sRte" id="RteSP19" style="color: BLUE;"><?= $this->getLHCRte('RteSP19', $this->played) ?></span>
                            <input type="text" tabindex="19" maxlength="5" id="CdtSP19" name="SP" acno="19">
                        </td>
    
                        <td class="boldborder">
                            <span title="29" class="hkball sCBHKball_29"></span>
                            <span class="sRte" id="RteSP29" style="color: BLUE;"><?= $this->getLHCRte('RteSP29', $this->played) ?></span>
                            <input type="text" tabindex="29" maxlength="5" id="CdtSP29" name="SP" acno="29">
                        </td>
    
                        <td class="boldborder">
                            <span title="39" class="hkball sCBHKball_39"></span>
                            <span class="sRte" id="RteSP39" style="color: BLUE;"><?= $this->getLHCRte('RteSP39', $this->played) ?></span>
                            <input type="text" tabindex="39" maxlength="5" id="CdtSP39" name="SP" acno="39">
                        </td>
    
                        <td class="">
                            <span title="49" class="hkball sCBHKball_49"></span>
                            <span class="sRte" id="RteSP49" style="color: BLUE;"><?= $this->getLHCRte('RteSP49', $this->played) ?></span>
                            <input type="text" tabindex="49" maxlength="5" id="CdtSP49" name="SP" acno="49">
                        </td>
    </tr><tr>

                        <td class="boldborder">
                            <span title="10" class="hkball sCBHKball_10"></span>
                            <span class="sRte" id="RteSP10" style="color: BLUE;"><?= $this->getLHCRte('RteSP10', $this->played) ?></span>
                            <input type="text" tabindex="10" maxlength="5" id="CdtSP10" name="SP" acno="10">
                        </td>
    
                        <td class="boldborder">
                            <span title="20" class="hkball sCBHKball_20"></span>
                            <span class="sRte" id="RteSP20" style="color: BLUE;"><?= $this->getLHCRte('RteSP20', $this->played) ?></span>
                            <input type="text" tabindex="20" maxlength="5" id="CdtSP20" name="SP" acno="20">
                        </td>
    
                        <td class="boldborder">
                            <span title="30" class="hkball sCBHKball_30"></span>
                            <span class="sRte" id="RteSP30" style="color: BLUE;"><?= $this->getLHCRte('RteSP30', $this->played) ?></span>
                            <input type="text" tabindex="30" maxlength="5" id="CdtSP30" name="SP" acno="30">
                        </td>
    
                        <td class="boldborder">
                            <span title="40" class="hkball sCBHKball_40"></span>
                            <span class="sRte" id="RteSP40" style="color: BLUE;"><?= $this->getLHCRte('RteSP40', $this->played) ?></span>
                            <input type="text" tabindex="40" maxlength="5" id="CdtSP40" name="SP" acno="40">
                        </td>
    <td>&nbsp;</td>
</tr>

        </tbody></table>
        <table>
            <tbody><tr>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        特大
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPBSOED" style="color: BLUE;"><?= $this->getLHCRte('RteSPBSOED', $this->played) ?></span><input type="text" tabindex="50" maxlength="5" id="CdtSPBSD" name="SPBSOE" acno="特大">
                    </td>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        特单
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPBSOEO" style="color: BLUE;"><?= $this->getLHCRte('RteSPBSOEO', $this->played) ?></span><input type="text" tabindex="52" maxlength="5" id="CdtSPOEO" name="SPBSOE" acno="特单">
                    </td>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        合大
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPTBSOED" style="color: BLUE;"><?= $this->getLHCRte('RteSPTBSOED', $this->played) ?></span><input type="text" tabindex="54" maxlength="5" id="CdtSPTBSD" name="SPTBSOE" acno="合大">
                    </td>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        合单
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPTBSOEO" style="color: BLUE;"><?= $this->getLHCRte('RteSPTBSOEO', $this->played) ?></span><input type="text" tabindex="56" maxlength="5" id="CdtSPTOEO" name="SPTBSOE" acno="合单">
                    </td>
    
                    <td width="45">
                        <span class="sGameStatusItem">
                        特尾大
                        </span>
                    </td>
                    <td class="">
                        <span class="sRte" id="RteSPSBSD" style="color: BLUE;"><?= $this->getLHCRte('RteSPSBSD', $this->played) ?></span><input type="text" tabindex="58" maxlength="5" id="CdtSPSBSD" name="SPSBS" acno="特尾大">
                    </td>
    </tr><tr>

                    <td width="38">
                        <span class="sGameStatusItem">
                        特小
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPBSOES" style="color: BLUE;"><?= $this->getLHCRte('RteSPBSOES', $this->played) ?></span><input type="text" tabindex="51" maxlength="5" id="CdtSPBSS" name="SPBSOE" acno="特小">
                    </td>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        特双
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPBSOEE" style="color: BLUE;"><?= $this->getLHCRte('RteSPBSOEE', $this->played) ?></span><input type="text" tabindex="53" maxlength="5" id="CdtSPOEE" name="SPBSOE" acno="特双">
                    </td>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        合小
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPTBSOES" style="color: BLUE;"><?= $this->getLHCRte('RteSPTBSOES', $this->played) ?></span><input type="text" tabindex="55" maxlength="5" id="CdtSPTBSS" name="SPTBSOE" acno="合小">
                    </td>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        合双
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPTBSOEE" style="color: BLUE;"><?= $this->getLHCRte('RteSPTBSOEE', $this->played) ?></span><input type="text" tabindex="57" maxlength="5" id="CdtSPTOEE" name="SPTBSOE" acno="合双">
                    </td>
    
                    <td width="45">
                        <span class="sGameStatusItem">
                        特尾小
                        </span>
                    </td>
                    <td class="">
                        <span class="sRte" id="RteSPSBSS" style="color: BLUE;"><?= $this->getLHCRte('RteSPSBSS', $this->played) ?></span><input type="text" tabindex="59" maxlength="5" id="CdtSPSBSS" name="SPSBS" acno="特尾小">
                    </td>
    </tr><tr>

                    <td width="38">
                        <span class="sGameStatusItem">
                        大单
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPH2DO" style="color: BLUE;"><?= $this->getLHCRte('RteSPH2DO', $this->played) ?></span><input type="text" tabindex="60" maxlength="5" id="CdtSPDODO" name="SPH2" acno="大单">
                    </td>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        大双
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPH2DE" style="color: BLUE;"><?= $this->getLHCRte('RteSPH2DE', $this->played) ?></span><input type="text" tabindex="61" maxlength="5" id="CdtSPDEDE" name="SPH2" acno="大双">
                    </td>
    
                    <td width="38">
                        <span class="sGameStatusItem">
                        小单
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPH2SO" style="color: BLUE;"><?= $this->getLHCRte('RteSPH2SO', $this->played) ?></span><input type="text" tabindex="62" maxlength="5" id="CdtSPSOSO" name="SPH2" acno="小单">
                    </td>
    
                    <td width="45">
                        <span class="sGameStatusItem">
                        小双
                        </span>
                    </td>
                    <td class="boldborder">
                        <span class="sRte" id="RteSPH2SE" style="color: BLUE;"><?= $this->getLHCRte('RteSPH2SE', $this->played) ?></span><input type="text" tabindex="63" maxlength="5" id="CdtSPSESE" name="SPH2" acno="小双">
                    </td>
    <td colspan="2">&nbsp;</td>
</tr>

        </tbody></table>
        <div class="space"></div>
    </div>
<div id="dResult">
    <input type="button" value="重设" onclick="resetTotalCredit();" name="重设">
    <input type="button" value="确定" onclick="bringRte();" name="确定">
    <span id="sTotalCredit" class="sTotal FontBold">0</span>
    <span>总计额度</span>
</div>
<div class="space"></div>